import java.awt.Color;
import java.awt.Graphics;

public class Panel extends Loop {
	
	public Panel() {
		
        setLayout(null);
        
        
        //Main.menu = new MyMenu();
        //add(Main.menu.getButton().getJButton());

        
        revalidate();
        repaint();
	}
	
	
    @Override
    public void paint(Graphics g) {

        
        setBackground(g,Color.WHITE);
        Main.drawing(g);
        
        
    }
    
    public void setBackground(Graphics g,Color color) {
    	g.setColor(color);
        g.fillRect(0,0,getWidth(),getHeight());
    }
}
