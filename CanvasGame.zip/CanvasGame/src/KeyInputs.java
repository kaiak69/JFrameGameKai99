import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyInputs implements KeyListener{
    static boolean[] isKeysPressed  = new boolean[256];

    public void SetCanvasInput(Panel panel){
        panel.addKeyListener(this);
        panel.setFocusable(true);
    }

    @Override
    public void keyPressed(KeyEvent e){
        isKeysPressed[e.getKeyCode()] = true; 
    }

    @Override
    public void keyReleased(KeyEvent e){
        isKeysPressed[e.getKeyCode()] = false;
    }

    @Override
    public void keyTyped(KeyEvent e){

    }
    
    
}