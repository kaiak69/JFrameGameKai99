import java.awt.*;
import java.util.Dictionary;
import java.util.Hashtable;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

public class Player{
	private int posX;
	private int posY;
	private int width;
	private int height;
	private textureImage[] texturesPlayer;
	//private Dictionary<String,textureImage>texturesPlayer = new Hashtable<>();
	private int animationSpeed = 15;
	private int frameCounter = 0;
	private int speed;
	private String lastDirection;
	public static int TOT_PLAYER_TEXTURES = 14;
	private textureImage activeTexture;
	
	public Player() {
		this.width=200;
		this.height=200;
		this.posX=0;
		this.posY=0;
		//this.posX=Window.WINDOW.width/2-this.width/2;
		//this.posY=Window.WINDOW.height-this.height;
		this.texturesPlayer = textureImage.loadPlayerTextures();
		this.speed=4;
		this.lastDirection = "idle_right_down";
		this.activeTexture= this.texturesPlayer[3]; //idle_right_down
	}
	
	public boolean changeTexture(String textureName,String textureType,String textureFolder) {
		String[] texture = textureImage.returnFileArray(textureName);
		ImageIcon icon;
		Image textureImg;
		if(texture!=null) {
			icon = new ImageIcon(textureImage.returnPath(texture, textureType,textureFolder));
			textureImg = icon.getImage();
			this.activeTexture.setPlayerTexture(textureImg);
			return true;
		}
		else {
			System.out.println("Texture non trovata!");
			return false;
		}
		
	}
	
	
	
	public String toString() {
	    return "Player{" +
	            "posX=" + posX +
	            ", posY=" + posY +
	            ", width=" + width +
	            ", height=" + height +
	            ", texturePlayer=" + activeTexture +
	            '}';
	}
	
	public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
	
	public void drawPlayer(Graphics g) {
		
		g.drawImage(this.activeTexture.getPlayerTexture(),
				this.posX,
				this.posY,
				this.posX + this.width,
	            this.posY + this.height, 
				this.activeTexture.getSrcX1(),
				this.activeTexture.getSrcY1(),
				this.activeTexture.getSrcX2(),
				this.activeTexture.getSrcY2(),
				null);
		//System.out.println(this.texturePlayer.getFrameIdx());
		
	}
	
	public void updatePlayer() {
		this.movePlayer();
		this.updateAnimation();
	}
	
	

	public void movePlayer() {
	    boolean isMoving = false;
	    
	    if (KeyInputs.isKeysPressed[KeyEvent.VK_D]) {
	        this.setPosX(this.getPosX() + this.speed);
	        this.setPosY(this.getPosY() - this.speed);
	        changeTexture("walk_right_up","Player","Walk");
	        isMoving = true;
	        lastDirection = "idle_right_up";
	    }
	    
	    else if (KeyInputs.isKeysPressed[KeyEvent.VK_A]) {
	        this.setPosX(this.getPosX() - this.speed);
	        this.setPosY(this.getPosY() + this.speed);
	        changeTexture("walk_left_down","Player","Walk");
	        isMoving = true;
	        lastDirection = "idle_left_down";
	    }
	    else if (KeyInputs.isKeysPressed[KeyEvent.VK_W]) {
	        this.setPosX(this.getPosX() - this.speed);
	        this.setPosY(this.getPosY() - this.speed);
	        changeTexture("walk_left_up","Player","Walk");
	        isMoving = true;
	        lastDirection = "idle_left_up";
	    }
	    else if (KeyInputs.isKeysPressed[KeyEvent.VK_S]) {
	        this.setPosX(this.getPosX() + this.speed);
	        this.setPosY(this.getPosY() + this.speed);
	        changeTexture("walk_right_down","Player","Walk");
	        isMoving = true;
	        lastDirection = "idle_right_down";
	    }
	    
	    if (isMoving) {
	        frameCounter++;
	        if (frameCounter >= animationSpeed) {
	            this.activeTexture.nextFrame();
	            frameCounter = 0;
	        }
	    } else {
	    	changeTexture(lastDirection,"Player","Idle");
	    }
	}

	
	
	
	private void updateAnimation() {
        frameCounter++;
        if (frameCounter >= animationSpeed) {
            this.activeTexture.nextFrame();
            frameCounter = 0;
        }
        this.activeTexture.updateTexture();
    }
		
}