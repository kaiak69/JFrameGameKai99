import java.awt.Image;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;

public class textureImage {
	private Image playerTexture;
	private int frameWidth;
	private int frameHeight;
	private int frameIdx;
	private int totalFrames;
	private  int srcX1;
	private  int srcX2;
	private  int srcY1;
	private  int srcY2;
	
	public textureImage(String path) {
		
		ImageIcon icon = new ImageIcon(path);
		this.playerTexture = icon.getImage();
		this.totalFrames=8;
		this.frameWidth=this.playerTexture.getWidth(null)/this.totalFrames;
		this.frameHeight=this.playerTexture.getHeight(null);
		this.frameIdx=0;
		this.srcX1=this.frameWidth;
		this.srcX2=this.frameWidth+this.frameWidth;
		this.srcY1=0;
		this.srcY2=this.frameHeight;
	}
	
	public void updateTexture() {
		this.srcX1=this.frameIdx*this.frameWidth;
		this.srcX2=this.srcX1+this.frameWidth;
	}
	
	public static String returnPath(String[] partsTexture,String textureType,String textureFolder) {
		String path="";
		if(textureType.equals("Player")) {
			path+="EntityImg/Adventurer/";
			if(textureFolder.equals("Idle")) {
				path+="Idle/";
			}
			else if(textureFolder.equals("Walk")) {
				path+="Walk/";
			}
			
			
		}	
		else if(textureType.equals("Item")) {
			path+="Items/";
		}
		path+=partsTexture[0]+".png";
		return path;
	}
	

	
	public static String[] returnFileArray(String textureName) {
        String line;
        String fileName = "textureList.txt"; 
         
        
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while ((line = reader.readLine()) != null) {
               
                String[] parts = line.split(" ");
                if(parts.length>0) {
                	if(parts[0].equals(textureName)) {
                    	return parts;
                    }
                }
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; 
    }
	
	public static textureImage[] loadPlayerTextures(){
		textureImage[] textures = new textureImage[Player.TOT_PLAYER_TEXTURES];
		String line;
        String fileName = "textureList.txt"; 
        textureImage image;
        int i=0;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while ((line = reader.readLine()) != null) {
               
                String[] parts = line.split("\\s+");
                if(parts.length>0 && parts[0].equals("TextureName")!=true) {
                	System.out.println(parts[0]);
                	if(parts[0].equals("\\")) return textures;
                	textures[i] = new textureImage(returnPath(parts,"Player",parts[1]));
                	i++;
                	
                }
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; 
	}
	
	
	
	public void nextFrame() {
		this.frameIdx = (this.frameIdx + 1) % totalFrames;
	}
	
	
	public String toString() {
	    return "textureImage{" +
	            "frameWidth=" + frameWidth +
	            ", frameHeight=" + frameHeight +
	            ", frameIdx=" + frameIdx +
	            ", srcX1=" + srcX1 +
	            ", srcX2=" + srcX2 +
	            ", srcY1=" + srcY1 +
	            ", srcY2=" + srcY2 +
	            '}';
	}
	
	public Image getPlayerTexture() {
		return this.playerTexture;
	}
	
	public void setPlayerTexture(Image playerTexture) {
		this.playerTexture=playerTexture;
	}
	
	public int getFrameWidth() {
        return frameWidth;
    }

    public void setFrameWidth(int frameWidth) {
        this.frameWidth = frameWidth;
    }

    public int getFrameHeight() {
        return frameHeight;
    }

    public void setFrameHeight(int frameHeight) {
        this.frameHeight = frameHeight;
    }

    public int getFrameIdx() {
        return frameIdx;
    }

    public void setFrameIdx(int frameIdx) {
        this.frameIdx = frameIdx;
    }
    
	 public int getSrcX1() {
	     return srcX1;
	 }
	
	 public void setSrcX1(int srcX1) {
	     this.srcX1 = srcX1;
	 }
	
	public int getSrcY1() {
	    return srcY1;
	}
	
	public void setSrcY1(int srcY1) {
	    this.srcY1 = srcY1;
	}
	
	public int getSrcX2() {
	    return srcX2;
	}
	
	public void setSrcX2(int srcX2) {
	    this.srcX2 = srcX2;
	}
	
	public int getSrcY2() {
	    return srcY2;
	}
	
	public void setSrcY2(int srcY2) {
	    this.srcY2 = srcY2;
	}
	
}
