import java.awt.Color;
import java.awt.Graphics;



public class MyMenu{
	private int posX;
	private int posY;
	private int width;
	private int height;
	private Button button;
	
	
	
	public MyMenu() {
		this.posX=0;
		this.posY=0;
		this.width=300;
		this.height=300;
		this.button = new Button();
	}
	
	public void drawMenu(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillRect(Window.WINDOW.width/2-this.width/2, Window.WINDOW.height/2-this.height/2, this.width, this.height);
		
	}
	
	public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    
    public Button getButton() {
    	return this.button;
    }
    
    public void setButton(Button button) {
    	this.button=button;
    }
    
}
