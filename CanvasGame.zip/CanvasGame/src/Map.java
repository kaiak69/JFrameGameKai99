import java.awt.Graphics;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;

public class Map {
	private int[][] map;
	private int nCol;
	private int nRow;
	private Image texture;
	private int width;
	private int height;
	
	public Map() {
		this.nCol=8;
		this.nRow=8;
		this.map = new int[this.nCol][this.nRow];
		ImageIcon icon = new ImageIcon("Land/dirt1.png");
		this.texture = icon.getImage();
		this.width=70;
		this.height=70;
		
	}
	
	

	
	
	
	
}
