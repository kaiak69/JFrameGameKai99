import java.awt.Graphics;

public class Main{
	static Window window;
	static Panel panel;
	static Player player;
	static KeyInputs keyInputs = new KeyInputs();
	
	static Map map; 
	//static MyMenu menu;
	
	
	public static void main(String[] args) {
		window = new Window("UOOO",800,500);
		panel = new Panel();
		player = new Player();
		map = new Map();
		keyInputs.SetCanvasInput(panel);
		window.openWindow(panel);
		
		
		//window.setFullScreen();
		panel.run();
	}
	
	public static void render() {
		window.render();
	}
	
	public static void update() {
		player.updatePlayer();
	}
	
	public static void drawing(Graphics g) {
		
		player.drawPlayer(g);
		
		//menu.drawMenu(g);
	}
	
	
}
