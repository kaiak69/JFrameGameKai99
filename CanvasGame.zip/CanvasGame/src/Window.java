import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class Window extends JFrame{
    public static Dimension WINDOW;
	public static Toolkit toolkit = Toolkit.getDefaultToolkit();
	public static Dimension DISPLAY = toolkit.getScreenSize();
	
    public Window(String title,int width,int height) {
       super(title);
        
       
       WINDOW = new Dimension(width,height);
       setSize(WINDOW);
        
        
    }
    
    
    public void render() {
    	repaint();
    }
    
    public void openWindow(Panel panel) {
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	add(panel);
    	setVisible(true); 
    	setLocationRelativeTo(null); //far si che se è a schermo intero non venga centrato
    }
    
    public void setFullScreen(){
    	setSize(DISPLAY);
    	WINDOW = new Dimension(DISPLAY.width,DISPLAY.height);
    }
}
