import javax.swing.JButton;


public class Button {
	private JButton jbutton;
	private int posX;
	private int posY;
	private int width;
	private int height;
	private String buttonText;
	
	
	public Button() {
		this.posX=0;
		this.posY=0;
		this.width=100;
		this.height=100;
		this.buttonText="Click me";
		this.jbutton = new JButton("prova");
		this.jbutton.setBounds(this.posX, this.posY, this.width, this.height);
	}
	
	public JButton getJButton() {
        return jbutton;
    }

    public void setJButton(JButton jbutton) {
        this.jbutton = jbutton;
    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
