import javax.swing.JPanel;

public class Loop extends JPanel implements Runnable{
	private int fps = 60;
    private boolean running;
    private int currentFPS = 0;
    private int frameCount = 0;
    private long lastFPSUpdate = 0;
    private long wait = 1000 / fps;

    @Override
    public void run(){
        running = true;
        //long lastTime = System.nanoTime();
        //double nsFrame = 1000000000.0 / fps;
        while(running){
            //long now = System.nanoTime();
            //double delta = (now - lastTime) / nsFrame;
            //lastTime = now;
            Main.render();
            Main.update();

            frameCount++;
            if(System.currentTimeMillis() - lastFPSUpdate >= 1000){
                currentFPS = frameCount;
                frameCount = 0;
                lastFPSUpdate = System.currentTimeMillis();
                System.out.println("FPS: " + currentFPS);
            }
            try{
                Thread.sleep(wait);
            } catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}
